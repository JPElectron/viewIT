viewIT v2.5.0.3

(rev3)

Change: larger window scale to accommodate modern
        monitor and tablet screen resolutions
