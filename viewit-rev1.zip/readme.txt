viewIT v2.5.0.1

(rev1)

Change: INI format is [URL]~ [# of seconds]
                           ~ as separator
