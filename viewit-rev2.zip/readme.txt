viewIT v2.5.0.2

(rev2)

Change: INI format is [URL]| [# of seconds]
                           | as separator
