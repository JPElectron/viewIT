viewIT v2.5.0.4

(rev4)

Change: larger window scale to accommodate modern
        monitor and tablet screen resolutions

Change: INI format is [URL]| [# of seconds]
                           | as separator
